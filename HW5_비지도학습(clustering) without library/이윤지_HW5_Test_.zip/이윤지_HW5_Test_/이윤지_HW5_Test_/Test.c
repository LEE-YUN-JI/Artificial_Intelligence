#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

#define ROW 512
#define COL 512
#define MAX_K 64
#define MAX_CLUSTERS 128

typedef struct {
    float data[MAX_K];
    int cluster;
} Vector;

typedef struct {
    float centroid[MAX_K];
} Cluster;

void read_image(const char* filename, unsigned char image[ROW][COL]);
void create_vectors_from_image(unsigned char image[ROW][COL], Vector* vectors, int K, int* num_vectors);
int load_centroids(const char* filename, Cluster* clusters, int N, int K);
void assign_clusters(Vector* vectors, Cluster* clusters, int num_vectors, int K, int N);
float compute_distortion(Vector* vectors, Cluster* clusters, int num_vectors, int K);

int main() {
    int K_values[] = { 4, 16, 64 };
    int N_values[] = { 4, 8, 16, 32, 64, 128 };

    unsigned char image[ROW][COL];
    read_image("../../data/lena.img", image);

    for (int k_idx = 0; k_idx < 3; k_idx++) {
        int K = K_values[k_idx];
        int block_size = (int)sqrt((double)K);
        int num_vectors = (ROW / block_size) * (COL / block_size);

        Vector* vectors = (Vector*)malloc(sizeof(Vector) * num_vectors);
        if (!vectors) {
            printf("�޸� �Ҵ� ����!\n");
            exit(1);
        }

        create_vectors_from_image(image, vectors, K, &num_vectors);

        for (int n_idx = 0; n_idx < 6; n_idx++) {
            int N = N_values[n_idx];
            Cluster clusters[MAX_CLUSTERS];

            char centroid_filename[100];
            sprintf(centroid_filename, "../../data/clustering_K%d_N%d", K, N);

            if (!load_centroids(centroid_filename, clusters, N, K)) {
                printf("�߽��� ���� ����: %s\n", centroid_filename);
                continue;
            }

            assign_clusters(vectors, clusters, num_vectors, K, N);

            float distortion = compute_distortion(vectors, clusters, num_vectors, K);

            printf("lena.img | K=%d, N=%d | Distortion = %.2f\n", K, N, distortion);
        }
        free(vectors);
    }
    return 0;
}

void read_image(const char* filename, unsigned char image[ROW][COL]) {
    FILE* fp = fopen(filename, "rb");
    if (!fp) {
        printf("�̹��� ���� ���� ����: %s\n", filename);
        exit(1);
    }
    fread(image, sizeof(unsigned char), ROW * COL, fp);
    fclose(fp);
}

void create_vectors_from_image(unsigned char image[ROW][COL], Vector* vectors, int K, int* num_vectors) {
    int block_size = (int)sqrt((double)K);
    int idx = 0;
    for (int i = 0; i <= ROW - block_size; i += block_size) {
        for (int j = 0; j <= COL - block_size; j += block_size) {
            int d = 0;
            for (int bi = 0; bi < block_size; bi++) {
                for (int bj = 0; bj < block_size; bj++) {
                    vectors[idx].data[d++] = image[i + bi][j + bj];
                }
            }
            idx++;
        }
    }
    *num_vectors = (ROW / block_size) * (COL / block_size);
}

// �߽��� �ε�
int load_centroids(const char* filename, Cluster* clusters, int N, int K) {
    FILE* fp = fopen(filename, "rb");
    if (!fp) {
        printf("�߽��� ���� ���� ����: %s\n", filename);
        return 0;
    }
    for (int i = 0; i < N; i++) {
        fread(clusters[i].centroid, sizeof(float), K, fp);
    }
    fclose(fp);
    return 1;
}

void assign_clusters(Vector* vectors, Cluster* clusters, int num_vectors, int K, int N) {
    for (int i = 0; i < num_vectors; i++) {
        float min_dist = INFINITY;
        int min_index = 0;
        for (int j = 0; j < N; j++) {
            float dist = 0.0f;
            for (int k = 0; k < K; k++) {
                float diff = vectors[i].data[k] - clusters[j].centroid[k];
                dist += diff * diff;
            }
            if (dist < min_dist) {
                min_dist = dist;
                min_index = j;
            }
        }
        vectors[i].cluster = min_index; // ���� ����� Ŭ������ �Ҵ�
    }
}

// �ս� ���
float compute_distortion(Vector* vectors, Cluster* clusters, int num_vectors, int K) {
    float distortion = 0.0f;
    for (int i = 0; i < num_vectors; i++) {
        int c = vectors[i].cluster;
        float dist = 0.0f;
        for (int k = 0; k < K; k++) {
            float diff = vectors[i].data[k] - clusters[c].centroid[k];
            dist += diff * diff;
        }
        distortion += dist;
    }
    return distortion / num_vectors;
}