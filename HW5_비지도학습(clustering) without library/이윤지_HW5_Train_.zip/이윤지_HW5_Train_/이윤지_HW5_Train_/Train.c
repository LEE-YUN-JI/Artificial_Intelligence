#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

#define ROW 512
#define COL 512
#define NUM_TRAIN_IMAGES 19
#define MAX_K 64
#define MAX_CLUSTERS 128

typedef struct {
    float data[MAX_K];
    int cluster;
} Vector;

typedef struct {
    float centroid[MAX_K];
    int count;
} Cluster;

void read_image(const char* filename, unsigned char image[ROW][COL]);
void create_vectors_from_image(unsigned char image[ROW][COL], Vector* vectors, int K, int* num_vectors);
void initialize_centroids(Vector* vectors, Cluster* clusters, int num_vectors, int K, int N);
void assign_clusters(Vector* vectors, Cluster* clusters, int num_vectors, int K, int N);
int update_centroids(Vector* vectors, Cluster* clusters, int num_vectors, int K, int N);
float compute_distortion(Vector* vectors, Cluster* clusters, int num_vectors, int K);
void kmeans_clustering(Vector* vectors, Cluster* clusters, int num_vectors, int K, int N);
void save_centroids(Cluster* clusters, int N, int K);

int main() {
    int K_values[] = { 4, 16, 64 };
    int N_values[] = { 4, 8, 16, 32, 64, 128 };

    for (int k_idx = 0; k_idx < 3; k_idx++) {
        int K = K_values[k_idx];
        int block_size = (int)sqrt((double)K);
        int vectors_per_image = (ROW / block_size) * (COL / block_size);
        int total_vectors = NUM_TRAIN_IMAGES * vectors_per_image;

        Vector* all_vectors = (Vector*)malloc(sizeof(Vector) * total_vectors);
        if (!all_vectors) {
            printf("�޸� �Ҵ� ����!\n");
            exit(1);
        }

        int vec_offset = 0;
        for (int img_idx = 0; img_idx < NUM_TRAIN_IMAGES; img_idx++) {
            unsigned char image[ROW][COL];
            char filename[100];
            sprintf(filename, "../../Data/I%d.img", img_idx);
            read_image(filename, image);

            int num_vectors = 0;
            Vector* temp_vectors = (Vector*)malloc(sizeof(Vector) * vectors_per_image);
            if (!temp_vectors) {
                printf("�޸� �Ҵ� ����!\n");
                exit(1);
            }

            create_vectors_from_image(image, temp_vectors, K, &num_vectors);

            for (int v = 0; v < num_vectors; v++) {
                for (int kk = 0; kk < K; kk++)
                    all_vectors[vec_offset + v].data[kk] = temp_vectors[v].data[kk];
                all_vectors[vec_offset + v].cluster = 0;
            }
            vec_offset += num_vectors;

            free(temp_vectors);
        }

        for (int n_idx = 0; n_idx < 6; n_idx++) {
            int N = N_values[n_idx];
            Cluster clusters[MAX_CLUSTERS] = { 0 };

            printf("==== K=%d, N=%d ====\n", K, N);
            kmeans_clustering(all_vectors, clusters, total_vectors, K, N);
            save_centroids(clusters, N, K);
        }
        free(all_vectors);
    }
    return 0;
}

// �̹��� �� �� �б�
void read_image(const char* filename, unsigned char image[ROW][COL]) {
    FILE* fp = fopen(filename, "rb");
    if (!fp) {
        printf("�̹��� ���� ���� ����: %s\n", filename);
        exit(1);
    }
    fread(image, sizeof(unsigned char), ROW * COL, fp);
    fclose(fp);
}

// �� �̹������� ���� ����
void create_vectors_from_image(unsigned char image[ROW][COL], Vector* vectors, int K, int* num_vectors) {
    int block_size = (int)sqrt((double)K); // K=4->2, K=16->4, K=64->8
    int idx = 0;
    for (int i = 0; i <= ROW - block_size; i += block_size) {
        for (int j = 0; j <= COL - block_size; j += block_size) {
            int d = 0;
            for (int bi = 0; bi < block_size; bi++) {
                for (int bj = 0; bj < block_size; bj++) {
                    vectors[idx].data[d++] = image[i + bi][j + bj];
                }
            }
            idx++;
        }
    }
    *num_vectors = (ROW / block_size) * (COL / block_size);
}

// �߽��� �ʱ�ȭ
void initialize_centroids(Vector* vectors, Cluster* clusters, int num_vectors, int K, int N) {
    // ��ü ���
    for (int k = 0; k < K; k++) clusters[0].centroid[k] = 0.0f;
    for (int i = 0; i < num_vectors; i++)
        for (int k = 0; k < K; k++)
            clusters[0].centroid[k] += vectors[i].data[k];
    for (int k = 0; k < K; k++) clusters[0].centroid[k] /= num_vectors;

    int current_clusters = 1;
    while (current_clusters < N) {
        for (int i = 0; i < current_clusters; i++) {
            for (int k = 0; k < K; k++) {
                clusters[current_clusters + i].centroid[k] = clusters[i].centroid[k] + 0.01f;
                clusters[i].centroid[k] -= 0.01f;
            }
        }
        current_clusters *= 2;
    }
}

// ���� �Ҵ�
void assign_clusters(Vector* vectors, Cluster* clusters, int num_vectors, int K, int N) {
    for (int i = 0; i < num_vectors; i++) {
        float min_dist = INFINITY;
        int min_index = 0;
        for (int j = 0; j < N; j++) {
            float dist = 0.0f;
            for (int k = 0; k < K; k++) {
                float diff = vectors[i].data[k] - clusters[j].centroid[k];
                dist += diff * diff;
            }
            if (dist < min_dist) {
                min_dist = dist;
                min_index = j;
            }
        }
        vectors[i].cluster = min_index;
        clusters[min_index].count++;
    }
}

// �߽��� ����
int update_centroids(Vector* vectors, Cluster* clusters, int num_vectors, int K, int N) {
    int changed = 0;
    float new_centroids[MAX_CLUSTERS][MAX_K] = { 0 };
    int counts[MAX_CLUSTERS] = { 0 };

    for (int i = 0; i < num_vectors; i++) {
        int c = vectors[i].cluster;
        for (int k = 0; k < K; k++) {
            new_centroids[c][k] += vectors[i].data[k];
        }
        counts[c]++;
    }

    for (int j = 0; j < N; j++) {
        if (counts[j] == 0) continue;
        for (int k = 0; k < K; k++) {
            float new_val = new_centroids[j][k] / counts[j];
            if (fabs(clusters[j].centroid[k] - new_val) > 1e-5) {
                changed = 1;
            }
            clusters[j].centroid[k] = new_val;
        }
        clusters[j].count = counts[j];
    }
    return changed;
}

// �ս�(distortion) ���
float compute_distortion(Vector* vectors, Cluster* clusters, int num_vectors, int K) {
    float distortion = 0.0f;
    for (int i = 0; i < num_vectors; i++) {
        int c = vectors[i].cluster;
        float dist = 0.0f;
        for (int k = 0; k < K; k++) {
            float diff = vectors[i].data[k] - clusters[c].centroid[k];
            dist += diff * diff;
        }
        distortion += dist;
    }
    return distortion / num_vectors;
}

// K-means
void kmeans_clustering(Vector* vectors, Cluster* clusters, int num_vectors, int K, int N) {
    initialize_centroids(vectors, clusters, num_vectors, K, N);

    double last_distortions[10] = { 1e9,1e9,1e9,1e9,1e9,1e9,1e9,1e9,1e9,1e9 }; // �ֱ� 10ȸ distortion
    int iter = 0;

    while (1) {
        for (int j = 0; j < N; j++) clusters[j].count = 0;
        assign_clusters(vectors, clusters, num_vectors, K, N);
        update_centroids(vectors, clusters, num_vectors, K, N);

        float distortion = compute_distortion(vectors, clusters, num_vectors, K);

        // ��ȭ�� ���
        for (int i = 0; i < 9; i++)
            last_distortions[i] = last_distortions[i + 1];
        last_distortions[9] = distortion;

        // ���� ��Ȳ ���
        double change = fabs(last_distortions[9] - last_distortions[8]);
        printf("[Iter %3d] Distortion: %.2f | Distortion change: %.5f | Cluster sizes: ", iter + 1, distortion, change);
        for (int j = 0; j < N; j++) printf("%d ", clusters[j].count);
        printf("\n");

        // ���� ����: 10�� ���� distortion ��ȭ���� 0.01 ����
        int stop = 1;
        for (int i = 0; i < 9; i++) {
            double diff = fabs(last_distortions[i + 1] - last_distortions[i]);
            if (diff > 0.01) {
                stop = 0;
                break;
            }
        }
        if (stop) {
            printf("Converged at iteration %d: distortion change <= 0.01 for last 10 iterations.\n\n\n", iter + 1);
            break;
        }

        iter++;
        if (iter > 10000) {
            printf("Warning: iteration exceeded 10000, force stop.\n");
            break;
        }
    }
}

// �߽��� ����
void save_centroids(Cluster* clusters, int N, int K) {
    char filename[100];
    sprintf(filename, "../../Data/clustering_K%d_N%d", K, N);
    FILE* fp = fopen(filename, "wb");
    if (!fp) {
        printf("�߽��� ���� ���� ����: %s\n", filename);
        return;
    }
    for (int i = 0; i < N; i++) {
        fwrite(clusters[i].centroid, sizeof(float), K, fp);
    }
    fclose(fp);
}